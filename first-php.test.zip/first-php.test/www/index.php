<?php
  require('partials/header.php');
?>

<?php 
if(isLogin()) {
  $user = getCurrentUser();
?>

  <h2>Приветствуем, <?php echo $user['username']; ?></h2>



  <?php 
  require('partials/twit.php');
  require('partials/all-twits.php');


  ?>




<?php
} else {
  ?>
   <h2>Приветствуем, введите логин и пароль </h2>
  <?php
}

?>

  <?php
    require('partials/footer.php');
  ?>




































































