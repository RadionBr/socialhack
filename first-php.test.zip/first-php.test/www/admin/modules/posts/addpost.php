<?php

	if(!empty($_POST)) {


		$sql = "INSERT INTO `posts` (`twit`, `user_id`) VALUES ('" . $_POST['name'] . "', '" . $_SESSION['user_id'] . "')";

		var_dump($_POST);
			
		if (mysqli_query($conn, $sql)) {
			echo "<h2>Дані оновлено. <a href='/admin/posts.php'>Повернутись</a></h2>";
		} else {
		      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
	}
	
?>	

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Posts list</h6>
                        </div>
                        <div class="card-body">

			 <form action="?page=add" method="POST">

			 	<div class="mb-3">
				  <label for="your twit" class="form-label">twit</label>
				  <input type="text" name="name" class="form-control" id="username" placeholder="Ennter your twit">
				</div>


				<button type="submit" class="btn btn-success btn-lg">Save</button>

			 </form>

	</div>
</div>









