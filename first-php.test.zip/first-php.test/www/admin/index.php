<?php
require($_SERVER['DOCUMENT_ROOT'] . '/admin/partials/header.php');
?>

    <!-- Page Wrapper -->
    <div id="wrapper">

    <?php 
	require($_SERVER['DOCUMENT_ROOT'] . '/admin/partials/sidebar.php');
	?>

	

    </div>	

<?php 
	require($_SERVER['DOCUMENT_ROOT'] . '/admin/partials/footer.php');
?>











































